<?php

namespace App\Entity;

use ApiPlatform\Core\Annotation\ApiResource;
use App\Repository\CartesRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ApiResource()
 * @ORM\Entity(repositoryClass=CartesRepository::class)
 */
class Cartes
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $code_couleur;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $details;

    /**
     * @ORM\Column(type="integer")
     */
    private $taches_id;

    /**
     * @ORM\Column(type="integer")
     */
    private $id_departement;

    /**
     * @ORM\Column(type="integer")
     */
    private $id_user;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getCodeCouleur(): ?string
    {
        return $this->code_couleur;
    }

    public function setCodeCouleur(string $code_couleur): self
    {
        $this->code_couleur = $code_couleur;

        return $this;
    }

    public function getDetails(): ?string
    {
        return $this->details;
    }

    public function setDetails(string $details): self
    {
        $this->details = $details;

        return $this;
    }

    public function getTachesId(): ?int
    {
        return $this->taches_id;
    }

    public function setTachesId(int $taches_id): self
    {
        $this->taches_id = $taches_id;

        return $this;
    }

    public function getIdDepartement(): ?int
    {
        return $this->id_departement;
    }

    public function setIdDepartement(int $id_departement): self
    {
        $this->id_departement = $id_departement;

        return $this;
    }

    public function getIdUser(): ?int
    {
        return $this->id_user;
    }

    public function setIdUser(int $id_user): self
    {
        $this->id_user = $id_user;

        return $this;
    }
}
