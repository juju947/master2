<?php

namespace App\Entity;

use ApiPlatform\Core\Annotation\ApiResource;
use App\Repository\DepartementRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ApiResource()
 * @ORM\Entity(repositoryClass=DepartementRepository::class)
 */
class Departement
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $direction_budget;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $direction_serv;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $direction_direction;

    /**
     * @ORM\Column(type="integer")
     */
    private $connect_id;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDirectionBudget(): ?string
    {
        return $this->direction_budget;
    }

    public function setDirectionBudget(string $direction_budget): self
    {
        $this->direction_budget = $direction_budget;

        return $this;
    }

    public function getDirectionServ(): ?string
    {
        return $this->direction_serv;
    }

    public function setDirectionServ(string $direction_serv): self
    {
        $this->direction_serv = $direction_serv;

        return $this;
    }

    public function getDirectionDirection(): ?string
    {
        return $this->direction_direction;
    }

    public function setDirectionDirection(string $direction_direction): self
    {
        $this->direction_direction = $direction_direction;

        return $this;
    }

    public function getConnectId(): ?int
    {
        return $this->connect_id;
    }

    public function setConnectId(int $connect_id): self
    {
        $this->connect_id = $connect_id;

        return $this;
    }
}
