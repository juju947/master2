<?php

namespace App\Entity;

use ApiPlatform\Core\Annotation\ApiResource;
use App\Repository\DirectionConectivitConnexesRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ApiResource()
 * @ORM\Entity(repositoryClass=DirectionConectivitConnexesRepository::class)
 */
class DirectionConectivitConnexes
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $service_connect;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getServiceConnect(): ?string
    {
        return $this->service_connect;
    }

    public function setServiceConnect(string $service_connect): self
    {
        $this->service_connect = $service_connect;

        return $this;
    }
}
